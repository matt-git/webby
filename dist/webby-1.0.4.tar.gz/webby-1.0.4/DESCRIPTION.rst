#Description file

Webby is built for python v2.7. It contains a powerful web crawler and parser to be used for web data mining.
