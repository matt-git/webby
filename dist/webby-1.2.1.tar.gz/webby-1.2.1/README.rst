# webby
Python Crawler and HTML Parser Library

- With webby you can quickly navigate the web
- pass html source code into a webby.Parser object 
- and use XPATHs to recieve web data. 
- The library comes packed with useful functions on 
- both the Crawler side and Parser side.

Version: 1.0.0

This includes the full documentation for webby.py module

Version: 1.0.0
	
	Creation Date: 10/27/2014
	
	Development of Current Version: 02/19/2015
	
	Developed By: Matthew McCullough

	
	Packaging Detail:
		Make sure you have urllib2 (built in python library, you should have this)
		Have lxml downloaded
		Have BeautifulSoup4 downloaded (bs4)
		
		
		
