#!C:\Python27\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'webby==1.0.0','console_scripts','sample'
__requires__ = 'webby==1.0.0'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('webby==1.0.0', 'console_scripts', 'sample')()
    )
